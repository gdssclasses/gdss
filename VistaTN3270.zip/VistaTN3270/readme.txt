Vista TN3270 For Windows                             
------------------------

Vista TN3270 For Windows is a program designed to emulate IBM
standard 3270 series terminals in a TN3270 (TCP) environment
provided by a standard WINSOCK interface.

Vista is written by:

    Tom Brennan
    523 N. Nora Ave.
    West Covina, CA 91790
    USA

If you need support, enhancements, registration information,
or just want to express your opinion of the product, please
send a note to:
     
    tom@tombrennansoftware.com

----------------------------------------------------------------

This program is distributed as a fully functioning version to 
allow users a free 30 day trial to see if it meets their needs.
To continue using the program after the trial, the user is
required to license (register) the program with the author.
See http://www.tombrennansoftware.com/order.html for details.

When Vista TN3270 is licensed to a single user, that user is
licensed to install and run this program on multiple computers, 
as long as only the licensed user is using the program.

Your organization may have purchased a group or site license,
in which you are then governed by the terms of the license
letter provided at purchase time.

----------------------------------------------------------------

Copyright 1998-2007 Tom Brennan
Portions Copyright (c) 1998-2003 The OpenSSL Project

This software is protected by current copyright law.  Any
unauthorized reproduction of distribution of this software or
any portion of it is not permitted without written permission
from the author.

----------------------------------------------------------------

This software is provided AS IS, and without a warranty of any
kind.  The author cannot guarantee the software to be free from
defects, and any problem arising from the use of this software
is at the sole risk of the user.  The author, and anyone else 
involved in the creation, modification, or distribution of this
software will not be liable for damages resulting from the use,
or inability to use this product.

By using this product, you acknowledge that you have
read this warranty disclaimer and agree with it.

----------------------------------------------------------------

This product includes software developed by the OpenSSL Project
for use in the OpenSSL Toolkit (http://www.openssl.org/)

This product includes cryptographic software written by
Eric Young (eay@cryptsoft.com)"

----------------------------------------------------------------

/*